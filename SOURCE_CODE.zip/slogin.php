<?php
session_start();
include("connection.php");
?>


<html>
    <head> 
        <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
    </head>
       <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    
                
                <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
    
        <div class="formholder">
            <form action="" method="post">
                    <p class="p4">Login to explore notes!</p> 
    <br>
          <div>
            <label  for="userEmail" >Email :</label>
            <br>        <input name="userEmail" type="email" placeholder=" enter your email" required>
            </div>

            <div>
            <label for="user_password">Password:</label>
            <br><input name="user_password" type="password" placeholder="enter password" required>
            </div>

            <div>
            <br>
            <button class="bn" name="sub" type="submit">LOGIN</button>
            </div>

            <h4 class="reg"> new user
		 <a href="ssignup.php">Click here</a>
</h4>
 <div>
                
                <h4 class="reg"><a href="../index.html">back</a></h4>
                </div>
    
<br>

            </form> 
</div>

<?php
   if(isset($_POST['sub']))
   {
     
       $us=$_POST['userEmail'];
   		$ps=$_POST['user_password'];
   		$q="SELECT * from student where semail='$us' and spassword='$ps'";
   		$run=mysqli_query($link,$q);
   		$row=mysqli_fetch_array($run);
       $_SESSION['id']=$row['sid'];
       $_SESSION['branch']=$row['sbranch'];
   		$p=$row['spassword'];
       $g=$row['semail'];
       $u=$row['sid'];
       $b=$row['sbranch'];
       $_SESSION['uid']=$u;
$_SESSION['branch']=$b;

      
   	if($us==$g and $ps==$p)
   		{
   			
         echo "<script>alert('login succesfull');document.location='shome.php'</script>";
                
   		}
   		else
   		{
        echo "<script>alert('login Unsuccesfull');document.location='slogin.php'</script>";
                
   		}

   }
?>
    </body>
    </html>