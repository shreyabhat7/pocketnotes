<?php
session_start();
$id=$_SESSION['uid'];
$b=$_SESSION['branch'];

include("connection.php");
?>
<html>
    <head><link rel="stylesheet" href="../css/p.css"></head>
          <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    
                
                  
                  <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
              
<form name="holder" action="fileview.php" method="post"> 
    <div class="lt">
   
        <center> <a href="fileview.php?e=1" style="color:navy;align:center;
    font-size:50px">semester-1</a>
         </center> 
        <center> <a href="fileview.php?e=2" style="color:navy;align:center;
    font-size:50px">semester-2</a>
         </center> 
        <center> <a href="fileview.php?e=3" style="color:navy;align:center;
    font-size:50px">semester-3</a>
         </center> 
        <center> <a href="fileview.php?e=4" style="color:navy;align:center;
    font-size:50px">semester-4</a>
         </center> 
        <center> <a href="fileview.php?e=5" style="color:navy;align:center;
    font-size:50px">semester-5</a>
         </center> 
        <center> <a href="fileview.php?e=6" style="color:navy;align:center;
    font-size:50px">semester-6</a>
         </center> 
        <center> <a href="fileview.php?e=7" style="color:navy;align:center;
    font-size:50px">semester-7</a>
         </center>
        <center> <a href="fileview.php?e=8" style="color:navy;align:center;
    font-size:50px">semester-8</a>
         </center>
    
    
    
    
    
    </div>
            
              
     
     
</form>
<div class="reg">
    <center><a href="shome.php">back</a></center>
              </div>
               <br>
           
<br>
    
            

          
     
</body>


</html>