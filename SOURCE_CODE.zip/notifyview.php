<?php
include("connection.php");
session_start();
$id=$_SESSION['uid'];
$b=$_SESSION['branch'];


?>
<html>
<head><link rel="stylesheet" href="../css/p.css"></head>
   <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    
                
                  
                  <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
              
<div class="container">
<table class="tableview">


<caption><b><h1>Notifications</h1></b></caption>
<thead>
<tr>
<th>Id</th>
<th>File</th>
<th>Action</th>

</tr>
</thead>
<tbody>
<?php

$dbhost = "localhost";
$dbuser = "id9238783_root";
$dbpass = "project1";
$dbname = "id9238783_pocketnotes";
$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die('cannot connect to the server'); 
$sql="select * from datas where dbranch='$b' and dtype='2'"; 

$stmt=$con->query($sql);
if($stmt->num_rows >0){


while($row=$stmt->fetch_assoc()){
    $e=$row["did"];
    echo'<tr><td>'.$row["did"];
    echo '</td><td>'.$row["dname"];
    echo '</td><td>';
    //echo '<a href="http://localhost/workshop/php/'.$row["dname"].'" style="color:crimson">download</a>';
 echo '<a href="'.$row["dfile"].'" style="color:crimson">download</a>';
   echo '</td></tr>';
}
echo "</table";

}
else{
    echo "<script>alert('No  Notifications Updated');</script>";
}
$con->close();
    ?>
  


</tbody>
</table>
<div class="reg"><a href="shome.php">back</a></div>
</div>
</body>
</html> 