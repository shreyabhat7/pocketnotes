<?php

include("connection.php");

?>
<html>
    <head> 
        <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
    </head>
        <body>              <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    

                <br>
            <br>
            
    <div class="outerdiv">
    
            <form action="" method="post">
                    <p class="p4">Change of password....</p>     
            
            <div>
            <label for="old_password">Old Password:</label>
            <br><input name="old_password" type="password" placeholder="enter password" required>
            </div>
                
                
            <div>
            <label for="new_password">New Password:</label>
            <br><input name="new_password" type="password" placeholder="enter password" required>
            </div>

            <div>
            <br>
            <button class="bn" name="sub" type="submit">change</button>
            </div>
                
 <div>
                <h4 class="reg"><a href="fhome.php">back</a>    </h4>

                </div>


            </form> 

</div>

    </body>
    </html>
    
    <?php
   if(isset($_POST['sub']))
   {
     $np=$_POST['new_password'];
   		$ps=$_POST['old_password'];
       
   		$q="SELECT * from student where spassword='$ps'";
   		$run=mysqli_query($link,$q);
   		$row=mysqli_fetch_array($run);
   		$p=$row['spassword'];
       $t=$row['sid'];

       if($ps==$p)
   		{
   			$q1="update student set spassword='$np' where sid='$t'";
            $run=mysqli_query($link,$q1);
            if(mysqli_affected_rows($link))
            {
               echo "<script>alert('successfully changed');document.location='shome.php'</script>";  
            }
   		}
   		else
   		{
        echo "<script>alert('does not match with old password...enter again');document.location='pass_reset1.php'</script>";
                
   		}
   	
   		

   }
?>
