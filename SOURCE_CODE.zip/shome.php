<?php
session_start();
$id=$_SESSION['uid'];
$b=$_SESSION['branch'];
include("connection.php");
?>
<html>
    <head> <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
        </head>
 <head> 
        <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
    </head>
           <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
                  
                  <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
              
<form name="holder" action="fileview.php" method="post"> 
 
<div>
<a href="section.php"><img  src="../img/bg.jpg" width="40%" height="18%"><h1>notes</h1></a>
</div>
<br>

<div>
<a href="notifyview.php"><img  src="../img/back.jpg" width="40%" height="18%"><h1>notifications</h1></a>

</div>
    
<div>
    <br>
<button type="button" onClick="goexit()">logout?</button>
</div>
      
</form>


              
</body>
<script>
  function goexit(){
    var logout = confirm("Are you sure to logout?");

if(logout){
     location.href = "../index.html";
}
  
  }
  </script>

</html>