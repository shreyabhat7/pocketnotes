<?php
$link=mysqli_connect('localhost','id9238783_root','project1','id9238783_pocketnotes');	
?>