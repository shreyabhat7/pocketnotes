<?php
include("connection.php");
session_start();
$id1=$_SESSION['uid'];
$b1=$_SESSION['branch'];


$y=$_GET['h'];

?>
<html>
<head><link rel="stylesheet" href="../css/p.css"></head>
   <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    
                
                  
                  <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
              
<div class="container">
<table class="tableview">

<caption><h1>all uploads after updation</h1></caption>

<tbody>
<?php

$dbhost = "localhost";
$dbuser = "id9238783_root";
$dbpass = "project1";
$dbname = "id9238783_pocketnotes";
$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die('cannot connect to the server'); 
    $ms=$_GET['h'];
   
    
$sql="delete from datas where did=".$ms.""; 
    if($con->query($sql)==true){


       $sql="select * from datas where dbranch='$b1' and fid='$id1'";  
    
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>dName</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $y=$row['did'];
    
        echo "<tr><td>".$y;
        echo"</td><td>".$row['dname'];
        echo"</td></tr>";
    }
    echo '</table>';
} else {
    echo "<script>alert('no  notes uploaded');</script>";
}



   
    }
    else
    {
        echo"none";
    }
    
$con->close();
    ?>

    
    
    
   <div>
                                <h4 class="reg">
                <a href="fhome.php">back</a></h4> </div>
    </tbody>  </table>
</div>
</body>
</html> 