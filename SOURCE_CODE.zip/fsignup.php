<?php
include("connection.php");
?>
<html>
    <head> 
        <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
    </head>
           <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    
                <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
              
    <div class="regholder">
            <form action="" method="POST">
                <p class="p4">Dont you have an account yet? Register!</p>           
        
                <div>
                <label  for="reg_fname" >FirstName :</label>
             <br>   <input name="reg_fname" type="text" placeholder=" enter your full name" required>
                </div>

                <div>
                    <label  for="reg_uname" >UserName :</label>
                 <br>   <input name="reg_uname" type="text" placeholder=" enter your username" required>
                    </div>
            
                <div>
                     <label  for="reg_email" >Email :</label>
                    <br><input name="reg_email" type="email" placeholder=" enter your email" required> 
                </div>
    

                <div>
                <label for="reg_pass">Password :</label>
                <br><input name="reg_pass" type="password" placeholder="enter password" required>  
                </div>

                <div>
                    <label for="reg_num">Contact number :</label>
                    <br><input name="reg_num" type="number" placeholder="enter mobile number" required>  
                </div>
 <div>
                   <label for="reg_branch">Branch : </label><br>
                    <select style="height:30px; text-align:center;size:20"name="reg_branch" >
                      
                        <option value="ise">ISE</option>
                         <option value="cse">CSE</option>
                        <option value="ece">ECE</option>
                        <option value="mech">MECH</option>
                
                                </select>  
                </div>

                <div>
                   <label for="reg_type">Type : </label>
                <br>
                    <select name="reg_type" >
                    <option value="1">FACULTY</option>
                    </select>  
                </div>


                <div>
                <br>
                <button class="btn" name="reg" type="submit">REGISTER</button>
                </div>

                <div class="reg">
                <a href="../index.html">back</a>
                </div>
          
                </form>
                </div>
                            <?php
   if(isset($_POST['reg']))
   {
       
   	    mysqli_select_db($link,"id9238783_pocketnotes");
   	   
   	    if(mysqli_query($link,"INSERT INTO faculty (fname,fusername,fpassword,femail,fcontact,fbranch)values ('".$_POST["reg_fname"]."','".$_POST["reg_uname"]."','".$_POST["reg_pass"]."','".$_POST["reg_email"]."','".$_POST["reg_num"]."','".$_POST["reg_branch"]."')"))
   	    {
                echo "<script>alert('Registered Successfully');document.location='flogin.php'</script>";
             
        }
   	    else
   	    {
   	    	echo "<script>alert('Registeration Unsuccesfull');document.location='fsignup.php'</script>";
                
        }
   }
?>
      
            
  
    
</body>
</html> 