<?php
session_start();
$fid=$_SESSION['uid'];
$b=$_SESSION['branch'];
include("connection.php");
?>

<html>
    <head> 
        <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
    </head>
          <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
    
                
                  
                  <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>
    
    <br>
        


    <div class="outerdiv">
    
    <form action="" method="post" >
            <p class="p4">welcome faculty!</p> 

  <div class="opp">
  
                <div>
                <br>
           <a href="fileupload.php" style="text-align:50px;">file upload</a>
                 
  
                </div>
            
            <div>
                <br>
          
        <a href="uploadlist.php">my uploads</a>
                </div>


                <div class="bt">
                    <br>
<button type="button" onClick="goexit()">logout?</button>
</div>
              
        </div>
<br>


    </form> 

</div>

    </body>
<script>
  function goexit(){
    var logout = confirm("Are you sure to logout?");

if(logout){
     location.href = "../index.html";
}
  
  }
  </script>

    </html>