
<?php

session_start();
$fid=$_SESSION['uid'];
$b=$_SESSION['branch'];

$dbhost = "localhost";
$dbuser = "id9238783_root";
$dbpass = "project1";
$dbname = "id9238783_pocketnotes";
$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die('cannot connect to the server'); 
if(isset($_POST['upload'])){
    $fn=$_POST['reg_name'];
    $sem=$_POST['r_sem'];
    $tp=$_POST['f_type'];
$allow = array("pdf","xls","doc","ppt","jpeg","jpg");
$temp = explode(".", $_FILES['uploadfile']['name']);
$extension = end($temp);
$upload_data=$_FILES['uploadfile']['name'];
move_uploaded_file($_FILES['uploadfile']['tmp_name'],$_FILES['uploadfile']['name']);
$sql="INSERT INTO datas(dfile,dname,sem,dtype,fid,dbranch)VALUES('".$upload_data."','".$fn."','".$sem."','".$tp."','".$fid."','".$b."')";
$q1=mysqli_query($con,$sql);
if($q1){
	echo "<script>alert('successfully uploaded')</script>";
}
else{
    echo "<script>alert(' not successfull')</script>";
}

}
?>

<html>
    <head> 
        <link rel="stylesheet" href="../css/p.css">
          <title>POCKET NOTES</title>
    </head>
        <body>
                <div class="top_bar"> POCKET NOTES : SMART WAY OF ACCESING NOTES</div>
                  
                  <div class="p2" >
                      <h1>Welcome to PocketNotes!</h1>
            </div>

    <div class="otdiv">
    <form action="" method="post" enctype="multipart/form-data">
            <p class="p4">welcome faculty!</p> 
  <div>
    <label  for="r_sem" >semester :</label>
    <br>        <input name="r_sem" type="number" placeholder=" enter your sem"  min="1" max="8" required>
    </div>

   <div>           <label  for="reg_name" >file Name: :</label>
             <br>   <input name="reg_name" type="text" placeholder=" enter your file name" required>
                </div>

 <div>
                   <label for="f_type">Type : </label><br>
                    <select name="f_type" >
                            <option value="1">notes</option>
                         <option value="2">notification</option>
                                </select>  
                </div>
<div >
    
    <label>choose file to upload :</label>
<input type="file" name="uploadfile"  id="uploadfile" style="display:inline" required>
    <br>
<input type="submit" name="upload" value="upload">
        </div>

<div>
    <br>
<button type="button" onClick="goBack()">back</button>
</div>
<br>
    </form> 

</div>

    </body>
    <script>
        function goBack(){
            window.history.back();
        }
        </script>
    </html>
     